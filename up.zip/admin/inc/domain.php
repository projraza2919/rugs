<?php
$domain="http://localhost/ahl"; 
 ?>